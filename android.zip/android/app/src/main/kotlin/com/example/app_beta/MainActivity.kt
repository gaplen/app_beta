package com.example.app_beta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
